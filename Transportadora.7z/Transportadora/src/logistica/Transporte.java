package logistica;

public interface Transporte {
    double calcularCustoEntrega();
}