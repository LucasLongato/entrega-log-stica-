package logistica;
public class TransporteAereo implements Transporte {
    private double valoresAduaneiros;
    private double tempoEsperaOrigem;
    private double tempoEsperaDestino;
    private double valorPorKg;
    private double pesoCarga;
    private double custoCombustivel;

    public TransporteAereo(double valoresAduaneiros, double tempoEsperaOrigem, double tempoEsperaDestino,
                            double valorPorKg, double pesoCarga, double custoCombustivel) {
        this.valoresAduaneiros = valoresAduaneiros;
        this.tempoEsperaOrigem = tempoEsperaOrigem;
        this.tempoEsperaDestino = tempoEsperaDestino;
        this.valorPorKg = valorPorKg;
        this.pesoCarga = pesoCarga;
        this.custoCombustivel = custoCombustivel;
    }

    @Override
    public double calcularCustoEntrega() {
        return (valoresAduaneiros + tempoEsperaOrigem + tempoEsperaDestino) * (valorPorKg * pesoCarga + custoCombustivel);
    }
}