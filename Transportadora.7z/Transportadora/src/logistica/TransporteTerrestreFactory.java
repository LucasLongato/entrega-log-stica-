package logistica;

public class TransporteTerrestreFactory implements ModalFactory {
    @Override
    public Transporte criarTransporte() {
        return new TransporteTerrestre(valorPorKm, kmRodados);
    }
}
