package logistica;


public class Main {

	 public static void main(String[] args) {
	        // Criando as fábricas
	        ModalFactory terrestreFactory = new TransporteTerrestreFactory();
	        ModalFactory aereoFactory = new TransporteAereoFactory();

	        // Criando os transportes
	        Transporte transporteTerrestre = terrestreFactory.criarTransporte();
	        Transporte transporteAereo = aereoFactory.criarTransporte();

	        // Ira calcular o custo de entrega
	        double custoTerrestre = transporteTerrestre.calcularCustoEntrega();
	        double custoAereo = transporteAereo.calcularCustoEntrega();

	        System.out.println("Custo do transporte terrestre: R$" + custoTerrestre);
	        System.out.println("Custo do transporte aéreo: R$" + custoAereo);
	    }
}
