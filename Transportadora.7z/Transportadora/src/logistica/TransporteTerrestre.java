package logistica;

public class TransporteTerrestre implements Transporte {
    private double valorPorKm;
    private double kmRodados;

    public TransporteTerrestre(double valorPorKm, double kmRodados) {
        this.valorPorKm = valorPorKm;
        this.kmRodados = kmRodados;
    }

    @Override
    public double calcularCustoEntrega() {
        return valorPorKm * kmRodados;
    }
}