package logistica;

public interface ModalFactory {
    Transporte criarTransporte();

	Transporte criarTransporte(double valorPorKm, double kmRodados);
}