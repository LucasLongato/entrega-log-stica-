package logistica;

public class TransporteAereoFactory implements ModalFactory {
    @Override
    public Transporte criarTransporte() {
     
		return new TransporteAereo(valoresAduaneiros, tempoEsperaOrigem, tempoEsperaDestino, valorPorKg, pesoCarga, custoCombustivel);
    }
}